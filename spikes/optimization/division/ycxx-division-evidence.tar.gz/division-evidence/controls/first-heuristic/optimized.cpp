using Word = unsigned long long;
extern "C" Word shift_1(Word x, Word salt) {
  return ((x / 2ULL) ^ salt) + 3 * (x % 2ULL);
}
extern "C" Word shift_5(Word x, Word salt) {
  return ((x / 32ULL) ^ salt) + 3 * (x % 32ULL);
}
extern "C" Word shift_16(Word x, Word salt) {
  return ((x / 65536ULL) ^ salt) + 3 * (x % 65536ULL);
}
extern "C" Word shift_31(Word x, Word salt) {
  return ((x / 2147483648ULL) ^ salt) + 3 * (x % 2147483648ULL);
}
extern "C" Word shift_40(Word x, Word salt) {
  return ((x / 1099511627776ULL) ^ salt) + 3 * (x % 1099511627776ULL);
}
extern "C" Word shift_63(Word x, Word salt) {
  return ((x / 9223372036854775808ULL) ^ salt) + 3 * (x % 9223372036854775808ULL);
}
