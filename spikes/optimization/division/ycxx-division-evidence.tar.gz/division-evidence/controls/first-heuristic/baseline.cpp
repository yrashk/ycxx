using Word = unsigned long long;
extern "C" Word divide_1(Word x, Word salt) {
  return ((x / 2ULL) ^ salt) + 3 * (x % 2ULL);
}
extern "C" Word divide_5(Word x, Word salt) {
  return ((x / 32ULL) ^ salt) + 3 * (x % 32ULL);
}
extern "C" Word divide_16(Word x, Word salt) {
  return ((x / 65536ULL) ^ salt) + 3 * (x % 65536ULL);
}
extern "C" Word divide_31(Word x, Word salt) {
  return ((x / 2147483648ULL) ^ salt) + 3 * (x % 2147483648ULL);
}
extern "C" Word divide_40(Word x, Word salt) {
  return ((x / 1099511627776ULL) ^ salt) + 3 * (x % 1099511627776ULL);
}
extern "C" Word divide_63(Word x, Word salt) {
  return ((x / 9223372036854775808ULL) ^ salt) + 3 * (x % 9223372036854775808ULL);
}
