import std;
import ycxx.bench.experiments;

using Word = unsigned long long;
using Function = Word (*)(Word, Word);
using namespace ycxx::bench;
using namespace ycxx::bench::experiments;
extern "C" Word divide_1(Word x, Word salt);
extern "C" Word shift_1(Word x, Word salt);
extern "C" Word divide_5(Word x, Word salt);
extern "C" Word shift_5(Word x, Word salt);
extern "C" Word divide_16(Word x, Word salt);
extern "C" Word shift_16(Word x, Word salt);
extern "C" Word divide_31(Word x, Word salt);
extern "C" Word shift_31(Word x, Word salt);
extern "C" Word divide_40(Word x, Word salt);
extern "C" Word shift_40(Word x, Word salt);
extern "C" Word divide_63(Word x, Word salt);
extern "C" Word shift_63(Word x, Word salt);

constexpr Word advance(Word word) {
  return word * 6364136223846793005ULL + 1442695040888963407ULL;
}

Word run_batch(Function f, Iterations iterations) {
  Word key = 1;
  Word state = 0;
  for (std::size_t i = 0; i < iterations; ++i) {
    key = advance(key);
    state = f(key, state);
  }
  return state;
}

struct Alternatives {
  std::uint64_t shift;
  Function divide;
  Function shift_mask;
};
const Alternatives variants[] = {
  {1, divide_1, shift_1},
  {5, divide_5, shift_5},
  {16, divide_16, shift_16},
  {31, divide_31, shift_31},
  {40, divide_40, shift_40},
  {63, divide_63, shift_63},
};

int main(int argc, char** argv) {
  const bool console = argc == 2 && std::string_view(argv[1]) == "--console";
  const SweepPoint points[] = {
    {Parameter::size, 1, "by 2^1"},
    {Parameter::size, 5, "by 2^5"},
    {Parameter::size, 16, "by 2^16"},
    {Parameter::size, 31, "by 2^31"},
    {Parameter::size, 40, "by 2^40"},
    {Parameter::size, 63, "by 2^63"},
  };
  auto config = configuration_for(Band::standard);
  config.process_telemetry = true;
  const auto results = sweep(points,
    [](const SweepPoint&) -> std::optional<Work> { return Work{1, "calls"}; },
    [&](const SweepPoint& point, const Work&) {
      const auto it = std::ranges::find(variants, point.value, &Alternatives::shift);
      Word x = 0;
      for (int i = 0; i < 100000; ++i) {
        const auto key = advance(x);
        if (it->divide(x, key) != it->shift_mask(x, key)) throw std::runtime_error("native mismatch");
        x = key;
      }
      return compare_batched(
        [&](Iterations n) { return run_batch(it->divide, n); },
        [&](Iterations n) { return run_batch(it->shift_mask, n); }, config);
    });
  if (!results) return 1;
  for (const auto& row : *results) {
    if (!row.result) return 2;
    const auto reference = std::format("-O0 {}", row.point.label);
    const auto optimized = std::format("heuristic {}", row.point.label);
    if (console) {
      write_console(std::cout, reference, optimized, *row.result);
      break;
    }
    write_ndjson(std::cout, reference, optimized, *row.result);
  }
}
