import std;
import ycxx.bench;

using Word = unsigned long long;
extern "C" Word separate_products(Word x, Word salt);
extern "C" Word shared_product(Word x, Word salt);

constexpr Word advance(Word word) {
  return word * 6364136223846793005ULL + 1442695040888963407ULL;
}

template<auto Operation>
Word run(ycxx::bench::Iterations iterations) {
  Word key = 1;
  Word state = 0;
  for (std::size_t i = 0; i < iterations; ++i) {
    key = advance(key);
    state = Operation(key, state);
  }
  return state;
}

int main(int argc, char** argv) {
  using namespace ycxx::bench;
  if (argc == 2 && (std::string_view(argv[1]) == "--memory-reference" ||
                    std::string_view(argv[1]) == "--memory-candidate")) {
    auto config = configuration_for(Band::standard);
    config.process_telemetry = true;
    const bool reference = std::string_view(argv[1]) == "--memory-reference";
    const auto result = reference ? measure_batched(run<separate_products>, config)
                                  : measure_batched(run<shared_product>, config);
    write_ndjson(std::cout, reference ? "two multiplications" : "shared multiply + shift", result);
    return 0;
  }
  Word x = 0;
  for (int i = 0; i < 100000; ++i) {
    const auto key = advance(x);
    if (separate_products(x, key) != shared_product(x, key)) return 1;
    x = key;
  }
  auto config = configuration_for(Band::standard);
  config.process_telemetry = true;
  const bool console = argc > 1;
  const bool terminal = console && stdout_is_terminal();
  TerminalProgress progress(std::cout, 2, config.profile);
  if (terminal) config.progress = std::ref(progress);
  const auto result = compare_batched(run<separate_products>, run<shared_product>, config);
  progress.clear();
  if (console) {
    write_console(std::cout, "two multiplications", "shared multiply + shift", result,
      terminal ? Style::ansi : Style::plain);
  } else write_ndjson(std::cout, "two multiplications", "shared multiply + shift", result);
}
