using Word = unsigned long long;

extern "C" Word separate_products(Word x, Word salt) {
  return ((x * 3) - (x * 6)) ^ salt;
}

extern "C" Word shared_product(Word x, Word salt) {
  const Word scaled = x * 3;
  return (scaled - (scaled << 1)) ^ salt;
}
