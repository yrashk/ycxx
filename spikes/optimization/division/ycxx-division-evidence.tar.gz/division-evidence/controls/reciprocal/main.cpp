import std;
import ycxx.bench.experiments;

using Word = unsigned long long;
using Function = Word (*)(Word, Word);
using namespace ycxx::bench;
using namespace ycxx::bench::experiments;
extern "C" Word divide_3(Word x, Word salt);
extern "C" Word shift_3(Word x, Word salt);
extern "C" Word divide_5(Word x, Word salt);
extern "C" Word shift_5(Word x, Word salt);
extern "C" Word divide_9(Word x, Word salt);
extern "C" Word shift_9(Word x, Word salt);
extern "C" Word divide_11(Word x, Word salt);
extern "C" Word shift_11(Word x, Word salt);
extern "C" Word divide_13(Word x, Word salt);
extern "C" Word shift_13(Word x, Word salt);
extern "C" Word divide_257(Word x, Word salt);
extern "C" Word shift_257(Word x, Word salt);

constexpr Word advance(Word word) {
  return word * 6364136223846793005ULL + 1442695040888963407ULL;
}

Word run_batch(Function f, Iterations iterations) {
  Word key = 1;
  Word state = 0;
  for (std::size_t i = 0; i < iterations; ++i) {
    key = advance(key);
    state = f(key, state);
  }
  return state;
}

struct Alternatives {
  std::uint64_t shift;
  Function divide;
  Function shift_mask;
};
const Alternatives variants[] = {
  {3, divide_3, shift_3},
  {5, divide_5, shift_5},
  {9, divide_9, shift_9},
  {11, divide_11, shift_11},
  {13, divide_13, shift_13},
  {257, divide_257, shift_257},
};

int main() {
  const SweepPoint points[] = {
    {Parameter::size, 3, "by 3"},
    {Parameter::size, 5, "by 5"},
    {Parameter::size, 9, "by 9"},
    {Parameter::size, 11, "by 11"},
    {Parameter::size, 13, "by 13"},
    {Parameter::size, 257, "by 257"},
  };
  auto config = configuration_for(Band::standard);
  config.process_telemetry = true;
  const auto results = sweep(points,
    [](const SweepPoint&) -> std::optional<Work> { return Work{1, "calls"}; },
    [&](const SweepPoint& point, const Work&) {
      const auto it = std::ranges::find(variants, point.value, &Alternatives::shift);
      Word x = 0;
      for (int i = 0; i < 100000; ++i) {
        const auto key = advance(x);
        if (it->divide(x, key) != it->shift_mask(x, key)) throw std::runtime_error("native mismatch");
        x = key;
      }
      return compare_batched(
        [&](Iterations n) { return run_batch(it->divide, n); },
        [&](Iterations n) { return run_batch(it->shift_mask, n); }, config);
    });
  if (!results) return 1;
  for (const auto& row : *results) {
    if (!row.result) return 2;
    write_ndjson(std::cout, std::format("32-bit divide {}", row.point.label),
      std::format("reciprocal multiply {}", row.point.label), *row.result);
  }
}
