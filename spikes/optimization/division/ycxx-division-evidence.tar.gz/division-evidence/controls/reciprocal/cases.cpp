using Word = unsigned long long;
extern "C" Word divide_3(Word x, Word salt) {
  return (static_cast<unsigned>(x) / 3u) ^ salt;
}
extern "C" Word shift_3(Word x, Word salt) {
  return ((static_cast<Word>(static_cast<unsigned>(x)) * 2863311531ULL) >> 33) ^ salt;
}
extern "C" Word divide_5(Word x, Word salt) {
  return (static_cast<unsigned>(x) / 5u) ^ salt;
}
extern "C" Word shift_5(Word x, Word salt) {
  return ((static_cast<Word>(static_cast<unsigned>(x)) * 3435973837ULL) >> 34) ^ salt;
}
extern "C" Word divide_9(Word x, Word salt) {
  return (static_cast<unsigned>(x) / 9u) ^ salt;
}
extern "C" Word shift_9(Word x, Word salt) {
  return ((static_cast<Word>(static_cast<unsigned>(x)) * 3817748708ULL) >> 35) ^ salt;
}
extern "C" Word divide_11(Word x, Word salt) {
  return (static_cast<unsigned>(x) / 11u) ^ salt;
}
extern "C" Word shift_11(Word x, Word salt) {
  return ((static_cast<Word>(static_cast<unsigned>(x)) * 3123612579ULL) >> 35) ^ salt;
}
extern "C" Word divide_13(Word x, Word salt) {
  return (static_cast<unsigned>(x) / 13u) ^ salt;
}
extern "C" Word shift_13(Word x, Word salt) {
  return ((static_cast<Word>(static_cast<unsigned>(x)) * 2643056798ULL) >> 35) ^ salt;
}
extern "C" Word divide_257(Word x, Word salt) {
  return (static_cast<unsigned>(x) / 257u) ^ salt;
}
extern "C" Word shift_257(Word x, Word salt) {
  return ((static_cast<Word>(static_cast<unsigned>(x)) * 4278255361ULL) >> 40) ^ salt;
}
